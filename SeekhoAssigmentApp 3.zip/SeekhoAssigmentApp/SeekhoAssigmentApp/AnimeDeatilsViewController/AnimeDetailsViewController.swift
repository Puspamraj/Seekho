//
//  AnimeDetailsViewController.swift
//  SeekhoAssigmentApp
//
//  Created by Pushpam Raj Chaudhary on 29/10/24.
//

import Foundation
import UIKit
import WebKit

class AnimeDetailViewController: UIViewController {
    // MARK: - Outlets
    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var plotLabel: UILabel!
    @IBOutlet weak var genresLabel: UILabel!
    @IBOutlet weak var episodesLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var trailerWebView: WKWebView!
    @IBOutlet weak var trailerNotAvailableLabel: UILabel!
    
    var animeID: Int!
    private let networkManager = NetworkManager()
    
    var imageFromList: String?

      override func viewDidLoad() {
          super.viewDidLoad()
          trailerWebView.navigationDelegate = self
          fetchAnimeDetails()
      }

      private func fetchAnimeDetails() {
          networkManager.fetchAnimeDetails(animeID: animeID) { [weak self] result in
              DispatchQueue.main.async {
                  switch result {
                  case .success(let details):
                      self?.updateUI(with: details)
                  case .failure(let error):
                      print("Error fetching details: \(error)")
                  }
              }
          }
      }

      private func updateUI(with details: AnimeDetail) {
          titleLabel.text = details.titleEnglish ?? details.title ?? "Title unavailable"
          plotLabel.text = details.synopsis ?? "No synopsis available"
          genresLabel.text = "Genres: " + (details.genres?.map { $0.name }.joined(separator: ", ") ?? "N/A")
          episodesLabel.text = "Episodes: \(details.episodes ?? 0)"
          ratingLabel.text = "Rating: \(details.score ?? 0.0)"
          
       //   loadImage(from: URL(string: imageFromList ?? "" )!)
         //  Load Poster Image
          if let imageUrlString = details.images?.jpg.imageUrl, let imageUrl = URL(string: imageUrlString) {
              loadImage(from: imageUrl)
          }

          // Load Trailer if available
          if let youtubeID = details.trailer?.youtubeId {
              trailerNotAvailableLabel.isHidden = true
              loadTrailer(youtubeID: youtubeID)
          } else {
              trailerWebView.isHidden = true  // Hide the trailer if it's unavailable
              trailerNotAvailableLabel.isHidden = false
          }
      }

      private func loadImage(from url: URL) {
          URLSession.shared.dataTask(with: url) { data, response, error in
              guard let data = data, let image = UIImage(data: data) else { return }
              DispatchQueue.main.async {
                  self.posterImageView.image = image
              }
          }.resume()
      }

      private func loadTrailer(youtubeID: String) {
          let youtubeURLString = "https://www.youtube.com/embed/\(youtubeID)"
          if let youtubeURL = URL(string: youtubeURLString) {
              trailerWebView.load(URLRequest(url: youtubeURL))
          }
      }
  }

  // MARK: - WKNavigationDelegate

  extension AnimeDetailViewController: WKNavigationDelegate {
      func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
          print("Failed to load trailer: \(error.localizedDescription)")
      }
  }
