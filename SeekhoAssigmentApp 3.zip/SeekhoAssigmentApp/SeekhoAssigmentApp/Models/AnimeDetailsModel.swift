//
//  AnimeDetailsModel.swift
//  SeekhoAssigmentApp
//
//  Created by Pushpam Raj Chaudhary on 29/10/24.
//

import Foundation

struct AnimeDetail: Decodable {
    let malId: Int?
    let url: String?
    let title: String?
    let titleEnglish: String?
    let titleJapanese: String?
    let titleSynonyms: [String]?
    let synopsis: String?
    let episodes: Int?
    let score: Double?
    let duration: String?
    let rating: String?
    let trailer: Trailer?
    let images: AnimeImages?
    let genres: [Genre]?
    let broadcast: Broadcast?

    struct Trailer: Decodable {
        let youtubeId: String?
        let url: String?
        let embedUrl: String?

        enum CodingKeys: String, CodingKey {
            case youtubeId = "youtube_id"
            case url
            case embedUrl = "embed_url"
        }
    }
    
    struct AnimeImages: Decodable {
        let jpg: ImageURL
    }

    struct ImageURL: Decodable {
        let imageUrl: String?
        
        enum CodingKeys: String, CodingKey {
            case imageUrl = "image_url"
        }
    }

    struct Genre: Decodable {
        let name: String
    }

    struct Broadcast: Decodable {
        let string: String?
    }

    enum CodingKeys: String, CodingKey {
        case malId = "mal_id"
        case url, title, titleEnglish = "title_english", titleJapanese = "title_japanese", titleSynonyms = "title_synonyms"
        case synopsis, episodes, score, duration, rating, trailer, images, genres, broadcast
    }
}
