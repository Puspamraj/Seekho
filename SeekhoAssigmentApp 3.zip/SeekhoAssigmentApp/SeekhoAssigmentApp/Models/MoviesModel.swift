//
//  MoviesModel.swift
//  SeekhoAssigmentApp
//
//  Created by Pushpam Raj Chaudhary on 29/10/24.
//

import Foundation

import Foundation

struct AnimeResponse: Decodable {
    let data: [Anime]
}

struct Anime: Decodable {
    let malId: Int
    let title: String
    let episodes: Int?
    let score: Double?
    let images: AnimeImages

    enum CodingKeys: String, CodingKey {
        case malId = "mal_id"
        case title, episodes, score, images
    }
}

struct AnimeImages: Decodable {
    let jpg: ImageURL
}

struct ImageURL: Decodable {
    let imageUrl: String?

    enum CodingKeys: String, CodingKey {
        case imageUrl = "image_url"
    }
}
