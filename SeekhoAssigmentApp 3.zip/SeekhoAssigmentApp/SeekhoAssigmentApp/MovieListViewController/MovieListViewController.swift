//
//  MovieListViewController.swift
//  SeekhoAssigmentApp
//
//  Created by Pushpam Raj Chaudhary on 29/10/24.
//

import UIKit

class MovieListViewController: UIViewController {
    
    @IBOutlet weak var animeListTableView: UITableView!
    
    private var animeList = [Anime]()
       private let networkManager = NetworkManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        registerTableViewCell()
        fetchTopAnime()
    }
    
    func registerTableViewCell() {
        //  animeListTableView.register(MovieCell.self, forCellReuseIdentifier: "MovieCell")
        
        animeListTableView.register(UINib(nibName: "MovieCell", bundle: Bundle(for: MovieCell.self)), forCellReuseIdentifier: "MovieCell")
        animeListTableView.dataSource = self
        animeListTableView.delegate = self
        animeListTableView.separatorStyle = .singleLine
    }
    
    private func fetchTopAnime() {
        networkManager.fetchTopAnime { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let animeList):
                    self?.animeList = animeList
                    self?.animeListTableView.reloadData()
                case .failure(let error):
                    print("Error fetching anime list: \(error)")
                }
            }
        }
        
    }
    
}

extension MovieListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return animeList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MovieCell", for: indexPath) as? MovieCell else {
            return UITableViewCell()
        }
        cell.selectionStyle = .none
        cell.animeModel = animeList[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let anime = animeList[indexPath.row]
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let detailVC = storyboard.instantiateViewController(withIdentifier: "AnimeDetailViewController") as? AnimeDetailViewController {
            detailVC.animeID = anime.malId
            detailVC.imageFromList = anime.images.jpg.imageUrl
            navigationController?.pushViewController(detailVC, animated: true)
        }
    }
    
}
