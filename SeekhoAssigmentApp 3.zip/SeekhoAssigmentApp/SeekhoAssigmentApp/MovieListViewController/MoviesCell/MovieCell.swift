//
//  MovieCell.swift
//  SeekhoAssigmentApp
//
//  Created by Pushpam Raj Chaudhary on 29/10/24.
//

import UIKit

class MovieCell: UITableViewCell {
    
    @IBOutlet weak var cellContentView: UIView!
    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var episodeLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    
    var animeModel: Anime? {
        didSet {
            configureCell()
        }
    }
    
    let imageCache = NSCache<NSString, UIImage>()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        cellContentView.styleWithShadow()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func configureCell() {
        if let imageUrlString = animeModel?.images.jpg.imageUrl {
              loadImage(from: imageUrlString)
          }
        
        titleLabel.text = animeModel?.title
        
        if let episodes = animeModel?.episodes {
            episodeLabel.text = "Episodes: \(episodes)"
        }
        if let rating =  animeModel?.score {
            ratingLabel.text = String(rating)
        }
    }
    
    private func loadImage(from urlString: String) {
            // Placeholder image
            posterImageView.image = UIImage(named: "placeholder")

            // Fetch image asynchronously with caching
            if let cachedImage = ImageCache.shared.image(forKey: urlString) {
                posterImageView.image = cachedImage
                return
            }

            guard let url = URL(string: urlString) else { return }
            URLSession.shared.dataTask(with: url) { data, response, error in
                guard let data = data, let image = UIImage(data: data) else { return }
                
                // Cache the image
                ImageCache.shared.save(image, forKey: urlString)

                // Update UI on main thread
                DispatchQueue.main.async {
                    self.posterImageView.image = image
                }
            }.resume()
        }
}

class ImageCache {
    static let shared = ImageCache()
    private let cache = NSCache<NSString, UIImage>()

    private init() {}

    func image(forKey key: String) -> UIImage? {
        return cache.object(forKey: key as NSString)
    }

    func save(_ image: UIImage, forKey key: String) {
        cache.setObject(image, forKey: key as NSString)
    }
}

public extension UIView {
    
    func styleWithShadow(cornerRadius: CGFloat = 10) {
        layer.cornerRadius = cornerRadius
        layer.shadowColor = UIColor.darkGray.cgColor
        layer.shadowOpacity = 0.4
        layer.shadowOffset = CGSize(width:0, height: 1)
        layer.shadowRadius = 2
    }
}
