//
//  NetworkManager.swift
//  SeekhoAssigmentApp
//
//  Created by Pushpam Raj Chaudhary on 29/10/24.
//

import Foundation


class NetworkManager {
    func fetchTopAnime(completion: @escaping (Result<[Anime], Error>) -> Void) {
        let urlString = "https://api.jikan.moe/v4/top/anime"
        guard let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else { return }
            do {
                let animeResponse = try JSONDecoder().decode(AnimeResponse.self, from: data)
                completion(.success(animeResponse.data))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
    
        func fetchAnimeDetails(animeID: Int, completion: @escaping (Result<AnimeDetail, Error>) -> Void) {
            let urlString = "https://api.jikan.moe/v4/anime/\(animeID)"
            guard let url = URL(string: urlString) else { return }
            
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    completion(.failure(error))
                    return
                }
                
                guard let data = data else { return }
                do {
                    let animeDetailResponse = try JSONDecoder().decode(AnimeDetailResponse.self, from: data)
                    completion(.success(animeDetailResponse.data))
                } catch {
                    completion(.failure(error))
                }
            }.resume()
        }
    }

    // Struct to handle the outer JSON response
    struct AnimeDetailResponse: Decodable {
        let data: AnimeDetail
    }
